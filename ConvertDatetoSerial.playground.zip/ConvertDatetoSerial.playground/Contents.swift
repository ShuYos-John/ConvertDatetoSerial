import UIKit

//insert any Day
var field:String = "2020/01/01,12:00"

//criterion at 2020/1/0
var criterion:Int = 737424

//returned serial value is stored here
var serialwithHour = Double()


func SerialConvert(){
    let Yearstr:String = String(field.prefix(4))
    let Monthstr:String = String(field[field.index(field.startIndex,offsetBy: 5)..<field.index(field.startIndex,offsetBy: 7)])
    let Daystr:String = String(field[field.index(field.startIndex, offsetBy: 8)..<field.index(field.startIndex, offsetBy: 10)])
    let Hourstr:String = String(field[field.index(field.startIndex,offsetBy: 11)..<field.index(field.startIndex,offsetBy: 13)])

    let Yeardouble = NumberFormatter().number(from: Yearstr) as! Int
    let Monthdouble = NumberFormatter().number(from: Monthstr) as! Int
    let Daydouble = NumberFormatter().number(from: Daystr) as! Int
    let HourDouble = NumberFormatter().number(from: Hourstr) as! Double
    
    let (fourhundredquotient,fourhundredreminder) = (Yeardouble-1).quotientAndRemainder(dividingBy: 400)
    let (hundredquotient,hundredreminder) = (Yeardouble-1).quotientAndRemainder(dividingBy: 100)
    let (fourquotient,fourreminder) = (Yeardouble-1).quotientAndRemainder(dividingBy: 4)

    let Jan:Int = 31
    var Feb:Int = 28
    if  fourhundredreminder == 399, hundredreminder == 99, fourreminder == 3{
        Feb = 29
    }else if hundredreminder == 99, fourreminder == 3 {
        Feb = 28
    }else if fourreminder == 3{
        Feb = 29
    }
    let Mar:Int = 31
    let Apr:Int = 30
    let May:Int = 31
    let Jun:Int = 30
    let Jul:Int = 31
    let Aug:Int = 31
    let Sep:Int = 30
    let Oct:Int = 31
    let Nov:Int = 30
    
    var monthserial:Int = 0
    if Monthdouble == 1 {
        monthserial = 0
    }
    if Monthdouble == 2 {
        monthserial = Jan
    }
    if Monthdouble == 3 {
        monthserial = Jan+Feb
    }
    if Monthdouble == 4 {
        monthserial = Jan+Feb+Mar
    }
    if Monthdouble == 5 {
        monthserial = Jan+Feb+Mar+Apr
    }
    if Monthdouble == 6 {
        monthserial = Jan+Feb+Mar+Apr+May
    }
    if Monthdouble == 7 {
        monthserial = Jan+Feb+Mar+Apr+May+Jun
    }
    if Monthdouble == 8 {
        monthserial = Jan+Feb+Mar+Apr+May+Jun+Jul
    }
    if Monthdouble == 9 {
        monthserial = Jan+Feb+Mar+Apr+May+Jun+Jul+Aug
    }
    if Monthdouble == 10 {
        monthserial = Jan+Feb+Mar+Apr+May+Jun+Jul+Aug+Sep
    }
    if Monthdouble == 11 {
        monthserial = Jan+Feb+Mar+Apr+May+Jun+Jul+Aug+Sep+Oct
    }
    if Monthdouble == 12 {
        monthserial = Jan+Feb+Mar+Apr+May+Jun+Jul+Aug+Sep+Oct+Nov
    }

    var yearserial:Int = 0
    yearserial = 365*(Yeardouble-1)+fourquotient-hundredquotient+fourhundredquotient-criterion

    let serial:Int = yearserial+monthserial+Daydouble
    let serialdouble:Double = Double(serial)

    serialwithHour = serialdouble + HourDouble/24

    print(serialwithHour)
}

SerialConvert()


