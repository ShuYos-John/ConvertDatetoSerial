import UIKit

//737424 is the serial value of 2020/1/0 as 0
var DateSerialvalue = 737424
var year = 0
var month = 0
var day = 0

func SerialtoDate (){
        
    let (fourhundredQuotient,fourhundredReminder) = Int(DateSerialvalue).quotientAndRemainder(dividingBy: 146097)
    //146097 = 365 * 400 + 1 * (100 + -4 + 1)
    let (hundredQuotient,hundredReminder) = (fourhundredReminder).quotientAndRemainder(dividingBy: 36524)
    //36524 = 365 * 100 + 1 * (25 + -1)
    let (fourQuotient,fourReminder) = (hundredReminder).quotientAndRemainder(dividingBy: 1461)
    //1461 = 365 * 4 + 1
    let (oneQuotient,oneReminder) = (fourReminder).quotientAndRemainder(dividingBy: 365)

    if oneReminder == 0{
        year = 400 * fourhundredQuotient + 100 * hundredQuotient + 4 * fourQuotient + oneQuotient
    }
    if oneReminder != 0{
        year = 400 * fourhundredQuotient + 100 * hundredQuotient + 4 * fourQuotient + oneQuotient + 1
    }

    let Jan:Int = 31
    var Feb:Int = 28
    if  145731 <= fourhundredReminder, fourhundredReminder <= 146097, 36158 <= hundredReminder, hundredReminder <= 36524, 1095 <= fourReminder, fourReminder <= 1461{
        Feb = 29
    }
    else if  36158 <= hundredReminder, hundredReminder <= 36524, 1095 <= fourReminder, fourReminder <= 1461{
        Feb = 28
    }
    else if  1095 <= fourReminder, fourReminder <= 1461{
        Feb = 29
    }
    let Mar:Int = 31
    let Apr:Int = 30
    let May:Int = 31
    let Jun:Int = 30
    let Jul:Int = 31
    let Aug:Int = 31
    let Sep:Int = 30
    let Oct:Int = 31
    let Nov:Int = 30
    
    if oneReminder == 0 {
        month = 12
        day = 31
    }else if oneReminder - (Jan+Feb+Mar+Apr+May+Jun+Jul+Aug+Sep+Oct+Nov) > 0 {
        month = 12
        day = oneReminder - (Jan+Feb+Mar+Apr+May+Jun+Jul+Aug+Sep+Oct+Nov)
    }else if oneReminder - (Jan+Feb+Mar+Apr+May+Jun+Jul+Aug+Sep+Oct) > 0{
        month = 11
        day = oneReminder - (Jan+Feb+Mar+Apr+May+Jun+Jul+Aug+Sep+Oct)
    }else if oneReminder - (Jan+Feb+Mar+Apr+May+Jun+Jul+Aug+Sep) > 0{
        month = 10
        day = oneReminder - (Jan+Feb+Mar+Apr+May+Jun+Jul+Aug+Sep)
    }else if oneReminder - (Jan+Feb+Mar+Apr+May+Jun+Jul+Aug) > 0{
        month = 9
        day = oneReminder - (Jan+Feb+Mar+Apr+May+Jun+Jul+Aug)
    }else if oneReminder - (Jan+Feb+Mar+Apr+May+Jun+Jul) > 0{
        month = 8
        day = oneReminder - (Jan+Feb+Mar+Apr+May+Jun+Jul)
    }else if oneReminder - (Jan+Feb+Mar+Apr+May+Jun) > 0{
        month = 7
        day = oneReminder - (Jan+Feb+Mar+Apr+May+Jun)
    }else if oneReminder - (Jan+Feb+Mar+Apr+May) > 0{
        month = 6
        day = oneReminder - (Jan+Feb+Mar+Apr+May)
    }else if oneReminder - (Jan+Feb+Mar+Apr) > 0{
        month = 5
        day = oneReminder - (Jan+Feb+Mar+Apr)
    }else if oneReminder - (Jan+Feb+Mar) > 0{
        month = 4
        day = oneReminder - (Jan+Feb+Mar)
    }else if oneReminder - (Jan+Feb) > 0{
        month = 3
        day = oneReminder - (Jan+Feb)
    }else if oneReminder - (Jan) > 0{
        month = 2
        day = oneReminder - (Jan)
    }else if oneReminder > 0{
        month = 1
        day = oneReminder
    }
}

SerialtoDate()
print("\(year)/\(month)/\(day)")
