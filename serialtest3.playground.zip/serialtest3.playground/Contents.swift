import UIKit

//insert any Day
var field:String = "2020/01/01,13:00"

//criterion at 2020/1/0
var criterion:Int = 737424


var serialwithHour = Double()


func SerialConvert(){


var Yearstr:String = String(field.prefix(4))
var Monthstr:String = String(field[field.index(field.startIndex,offsetBy: 5)..<field.index(field.startIndex,offsetBy: 7)])
var Daystr:String = String(field[field.index(field.startIndex, offsetBy: 8)..<field.index(field.startIndex, offsetBy: 10)])
var Hourstr:String = String(field[field.index(field.startIndex,offsetBy: 11)..<field.index(field.startIndex,offsetBy: 13)])

var Yeardouble = NumberFormatter().number(from: Yearstr) as! Int
var Monthdouble = NumberFormatter().number(from: Monthstr) as! Int
var Daydouble = NumberFormatter().number(from: Daystr) as! Int
var HourDouble = NumberFormatter().number(from: Hourstr) as! Double

let (fourhundredquotient,fourhundredreminder) = (Yeardouble-1).quotientAndRemainder(dividingBy: 400)
let (hundredquotient,hundredreminder) = (Yeardouble-1).quotientAndRemainder(dividingBy: 100)
let (fourquotient,fourreminder) = (Yeardouble-1).quotientAndRemainder(dividingBy: 4)

var Jan:Int = 31
var Feb:Int = 28
if  fourhundredreminder == 399, hundredreminder == 99, fourreminder == 3{
    Feb = 29
}else if hundredreminder == 99, fourreminder == 3 {
    Feb = 28
}else if fourreminder == 3{
    Feb = 29
} //　Consideration of leap year.
var Mar:Int = 31
var Apr:Int = 30
var May:Int = 31
var Jun:Int = 30
var Jul:Int = 31
var Aug:Int = 31
var Sep:Int = 30
var Oct:Int = 31
var Nov:Int = 30
var Dec:Int = 31

var monthserial:Int = 0
if Monthdouble == 1 {
    monthserial = 0
}
if Monthdouble == 2 {
 monthserial = Jan
}
if Monthdouble == 3 {
 monthserial = Jan+Feb
}
if Monthdouble == 4 {
 monthserial = Jan+Feb+Mar
}
if Monthdouble == 5 {
 monthserial = Jan+Feb+Mar+Apr
}
if Monthdouble == 6 {
    monthserial = Jan+Feb+Mar+Apr+May
}
if Monthdouble == 7 {
 monthserial = Jan+Feb+Mar+Apr+May+Jun
}
if Monthdouble == 8 {
 monthserial = Jan+Feb+Mar+Apr+May+Jun+Jul
}
if Monthdouble == 9 {
 monthserial = Jan+Feb+Mar+Apr+May+Jun+Jul+Aug
}
if Monthdouble == 10 {
 monthserial = Jan+Feb+Mar+Apr+May+Jun+Jul+Aug+Sep
}
if Monthdouble == 11 {
 monthserial = Jan+Feb+Mar+Apr+May+Jun+Jul+Aug+Sep+Oct
}
if Monthdouble == 12 {
 monthserial = Jan+Feb+Mar+Apr+May+Jun+Jul+Aug+Sep+Oct+Nov
}

var yearserial:Int = 0
yearserial = 365*(Yeardouble-1)+fourquotient-hundredquotient+fourhundredquotient-criterion

var serial:Int = yearserial+monthserial+Daydouble
var serialdouble:Double = Double(serial)

serialwithHour = serialdouble + HourDouble/24
}

print(serialwithHour)



